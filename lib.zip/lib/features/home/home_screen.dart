import 'package:flutter/material.dart';

import '../../core/constants/app_constants.dart';
import '../../core/utils/date_formatter.dart';
import '../../data/models/transaction.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final transactions = <TransactionModel>[
      TransactionModel(
        id: '1',
        title: 'Salary',
        amount: 3200,
        date: DateTime.now().subtract(const Duration(days: 1)),
        type: TransactionType.income,
        category: 'Salary',
      ),
      TransactionModel(
        id: '2',
        title: 'Groceries',
        amount: 84.5,
        date: DateTime.now().subtract(const Duration(days: 2)),
        type: TransactionType.expense,
        category: 'Food',
      ),
      TransactionModel(
        id: '3',
        title: 'Freelance',
        amount: 560,
        date: DateTime.now().subtract(const Duration(days: 4)),
        type: TransactionType.income,
        category: 'Side Hustle',
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appTitle),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Balance',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '\$${(3200 - 84.5 + 560).toStringAsFixed(2)}',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text('This month overview'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Recent transactions',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 12),
          ...transactions.map((item) => ListTile(
                leading: CircleAvatar(
                  child: Icon(item.type == TransactionType.income ? Icons.arrow_downward : Icons.arrow_upward),
                ),
                title: Text(item.title),
                subtitle: Text('${item.category ?? 'General'} • ${DateFormatter.format(item.date)}'),
                trailing: Text(
                  item.displayAmount,
                  style: TextStyle(
                    color: item.type == TransactionType.income ? Colors.green : Colors.red,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              )),
        ],
      ),
    );
  }
}
